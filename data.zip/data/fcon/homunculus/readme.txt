convert ho.gif  bild.pnm

pnmtov bild.pnm | vattredit -name voxel -value "1 1 1"  | vimage2nifti -out bild.nii.gz
pnmtov bild_black.pnm | vattredit -name voxel -value "1 1 1"  | vimage2nifti -out bild_black.nii.gz


fslmerge -z merge.nii.gz bild_black.nii.gz bild.nii.gz  bild.nii.gz bild.nii.gz bild_black.nii.gz


# crop images of the rainbow
for ((i=0;i<=15;i++));  do j=$((i*19)); convert -crop 19x40+$j+0 rainbow10.jpg rainbow7_"$i".png; done
